package com.example.teacher_management_system;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.os.Environment;
import android.view.View;
import android.widget.TextView;

import java.io.File;

public class about extends AppCompatActivity
{


    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_about);
        TextView textview =  findViewById(R.id.textView45);
        textview.setText("  This application is developed by\n   Abhishek Verma.\n " +
                "  Teacher's Management System.\n " +
                "  Features of this applications:\n\n" +
                "  1.Handling with Records.\n" +
                "  2.Handling with Attendance\n" +
                "  3.Handling with Grade \n" +
                "  4.Handling with Time-Table.\n\n\n\n\n"  +
                "   For any issue related to this  \n   application.\n" +
                "    www.teachers_management_.sy\n    stem.com" );
    }


    public void reset(View view)
    {
        File currentDir = getFilesDir();

        File file_1 = new File(currentDir,"grade.txt");
        File file_2 = new File(currentDir,"set.txt");
        File file_3 = new File(currentDir,"data.txt");
        File file1 = new File(currentDir,"19CSE1001.txt");
        File file2 = new File(currentDir,"19CSE1002.txt");
        File file3 = new File(currentDir,"19CSE1003.txt");
        File file4 = new File(currentDir,"19CSE1004.txt");
        File file5 = new File(currentDir,"19CSE1005.txt");
        File file6 = new File(currentDir,"19CSE1006.txt");
        File file7 = new File(currentDir,"19CSE1007.txt");
        File file8 = new File(currentDir,"19CSE1008.txt");
        File file9 = new File(currentDir,"19CSE1009.txt");
        File file10 = new File(currentDir,"19CSE1010.txt");
        File file11 = new File(currentDir,"19CSE1011.txt");
        File file12 = new File(currentDir,"19CSE1012.txt");
        File file13 = new File(currentDir,"19CSE1013.txt");
        File file14 = new File(currentDir,"19CSE1014.txt");
        File file15 = new File(currentDir,"19CSE1015.txt");
        File file16 = new File(currentDir,"19CSE1016.txt");
        File file17 = new File(currentDir,"19CSE1017.txt");
        File file18 = new File(currentDir,"19CSE1018.txt");
        File file19 = new File(currentDir,"19CSE1019.txt");
        File file20= new File(currentDir,"19CSE1020.txt");
        File file21 = new File(currentDir,"19CSE1021.txt");
        File file22 = new File(currentDir,"19CSE1022.txt");
        File file23 = new File(currentDir,"19CSE1023.txt");
        File file24 = new File(currentDir,"19CSE1024.txt");
        File file25 = new File(currentDir,"19CSE1025.txt");
        File file26 = new File(currentDir,"19CSE1026.txt");
        File file27 = new File(currentDir,"19CSE1027.txt");



        file1.delete();
        file2.delete();
        file3.delete();
        file4.delete();
        file5.delete();
        file6.delete();
        file7.delete();
        file8.delete();
        file9.delete();
        file10.delete();
        file11.delete();
        file12.delete();
        file13.delete();
        file14.delete();
        file15.delete();
        file16.delete();
        file17.delete();
        file18.delete();
        file19.delete();
        file20.delete();
        file21.delete();
        file22.delete();
        file23.delete();
        file24.delete();
        file25.delete();
        file26.delete();
        file27.delete();
        file_1.delete();
        file_2.delete();
        file_3.delete();
        File filee_1 = new File(currentDir,"security.txt");
        filee_1.delete();
        File filee_2 = new File(currentDir,"login.txt");
        filee_2.delete();
    }



}