package com.example.teacher_management_system;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.os.Environment;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

public class search_1 extends AppCompatActivity
{

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_search1);
    }


    public void search_2(View view)
    {

        EditText editText = findViewById(R.id.editTextTextPersonName7);
        TextView textview = findViewById(R.id.textView13);
        TextView textview1 = findViewById(R.id.textView20);
        TextView textview2 = findViewById(R.id.textView17);
        TextView textview3 = findViewById(R.id.textView22);

        try
        {
            File currentDir = getFilesDir();
            File filee = new File(currentDir, "data.txt");
            BufferedReader br = new BufferedReader(new FileReader(filee));
            String line = br.readLine();
            int i = 0;
            String temp = null;
            while (line != null)
            {
                temp = line;
                line = br.readLine();
                if (editText.getText().toString().equals(line))
                {
                    i=1;
                    textview.setText(temp);
                    line = br.readLine();
                    textview1.setText(line);
                    line = br.readLine();
                    textview2.setText(line);
                    line = br.readLine();
                    textview3.setText(line);
                    break;
                }

                line = br.readLine();
                line = br.readLine();
                line = br.readLine();
                line = br.readLine();

            }
            if(i==0)
            {
                textview.setText("Invalid");
                textview1.setText("Invalid");
                textview2.setText("Invalid");
                textview3.setText("Invalid");
            }

            br.close();

        }

        catch (FileNotFoundException e)
        {
            e.printStackTrace();
        }

        catch (IOException e)
        {
            e.printStackTrace();
        }

    }

}


