package com.example.teacher_management_system;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.os.Environment;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;

public class add extends AppCompatActivity
{

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add);
    }

    public void file(View view)
    {

        File currentDir = getFilesDir();

        EditText editText = findViewById(R.id.editTextTextPersonName2);
        EditText editText1 = findViewById(R.id.editTextTextPersonName3);
        EditText editText2 = findViewById(R.id.editTextTextPersonName4);
        EditText editText3 = findViewById(R.id.editTextTextPersonName5);
        EditText editText4 = findViewById(R.id.editTextTextPersonName6);

        File file = new File(currentDir,"data.txt");
        try
        {

            FileWriter fw = new FileWriter(file,true);
            PrintWriter pw = new PrintWriter(fw);
            pw.println(editText.getText().toString());
            pw.println(editText1.getText().toString());
            pw.println(editText2.getText().toString());
            pw.println(editText3.getText().toString());
            pw.println(editText4.getText().toString());
            pw.flush();
            pw.close();

        }
        catch (FileNotFoundException e)
        {
            e.printStackTrace();
        }
        catch (IOException e)
        {
            e.printStackTrace();
        }
    }

}