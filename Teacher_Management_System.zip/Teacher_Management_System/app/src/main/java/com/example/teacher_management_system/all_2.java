package com.example.teacher_management_system;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.os.Environment;
import android.view.View;
import android.widget.TextView;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

public class all_2 extends AppCompatActivity {



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_all2);
    }


    public void refresh(View view) {

        File currentDir = getFilesDir();

        TextView textview = findViewById(R.id.textView19);
        TextView textview1 = findViewById(R.id.textView60);
        TextView textview2 = findViewById(R.id.textView59);
        TextView textview3 = findViewById(R.id.textView58);
        TextView textview4 = findViewById(R.id.textView57);
        TextView textview5 = findViewById(R.id.textView56);
        TextView textview6 = findViewById(R.id.textView55);
        TextView textview7 = findViewById(R.id.textView54);
        TextView textview8 = findViewById(R.id.textView52);
        TextView textview9 = findViewById(R.id.textView3);
        TextView textview10 = findViewById(R.id.textView50);
        TextView textview11 = findViewById(R.id.textView65);
        TextView textview12 = findViewById(R.id.textView64);
        TextView textview13 = findViewById(R.id.textView63);
        TextView textview14 = findViewById(R.id.textView62);
        TextView textview15 = findViewById(R.id.textView61);
        TextView textview16 = findViewById(R.id.textView53);
        TextView textview17 = findViewById(R.id.textView51);


        try {
            File file = new File(currentDir, "data.txt");
            BufferedReader br = new BufferedReader(new FileReader(file));
            String line = br.readLine();
            for (int k = 1; k <= 90; k++)
                line = br.readLine();
            int i = 1;
            while (line != null) {

                line = br.readLine();
                switch (i) {
                    case 1:
                        textview.setText(line);
                        line = br.readLine();
                        break;

                    case 2:
                        textview1.setText(line);
                        line = br.readLine();
                        break;


                    case 3:
                        textview2.setText(line);
                        line = br.readLine();
                        break;


                    case 4:
                        textview3.setText(line);
                        line = br.readLine();
                        break;


                    case 5:
                        textview4.setText(line);
                        line = br.readLine();
                        break;


                    case 6:
                        textview5.setText(line);
                        line = br.readLine();
                        break;


                    case 7:
                        textview6.setText(line);
                        line = br.readLine();
                        break;


                    case 8:
                        textview7.setText(line);
                        line = br.readLine();
                        break;


                    case 9:
                        textview8.setText(line);
                        line = br.readLine();
                        break;

                }
                line = br.readLine();
                line = br.readLine();
                line = br.readLine();
                i++;

            }



                File f19 = new File(currentDir, "19CSE1019.txt");
                long j19 = f19.length();
                textview9.setText(String.valueOf(j19));

                File f20 = new File(currentDir, "19CSE1020.txt");
                long j20 = f20.length();
                textview10.setText(String.valueOf(j20));

                File f21 = new File(currentDir, "19CSE1021.txt");
                long j21 = f21.length();
                textview11.setText(String.valueOf(j21));

                File f22 = new File(currentDir, "19CSE1022.txt");
                long j22 = f22.length();
                textview12.setText(String.valueOf(j22));

                File f23 = new File(currentDir, "19CSE1023.txt");
                long j23 = f23.length();
                textview13.setText(String.valueOf(j23));

                File f24 = new File(currentDir, "19CSE1024.txt");
                long j24 = f24.length();
                textview14.setText(String.valueOf(j24));

                File f25 = new File(currentDir, "19CSE1025.txt");
                long j25 = f25.length();
                textview15.setText(String.valueOf(j25));

                File f26 = new File(currentDir, "19CSE1026.txt");
                long j26 = f26.length();
                textview16.setText(String.valueOf(j26));

                File f27 = new File(currentDir, "19CSE1027.txt");
                long j27 = f27.length();
                textview17.setText(String.valueOf(j27));

            br.close();
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }

    }

}