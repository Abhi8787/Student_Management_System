package com.example.teacher_management_system;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.os.Environment;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;


public class MainActivity extends AppCompatActivity
{
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void forgot(View view)
    {
        Intent intent = new Intent(this,forgot.class);
        startActivity(intent);
    }

    public void login(View view)
    {
        File currentDir = getFilesDir();

        Intent intent = new Intent(this,mainmenu.class);
        EditText editText1 =  findViewById(R.id.editTextTextPersonName);
        EditText editText2 =  findViewById(R.id.editTextTextPassword);

        File file = new File(currentDir,"login.txt");

        if(!file.exists()){
            try {
                FileWriter fw = new FileWriter(file);
                PrintWriter pw = new PrintWriter(file);
                pw.println("Abhishek");
                pw.println("123456");
                pw.close();
            }


            catch (FileNotFoundException e)
            {
                Toast.makeText(MainActivity.this,"FileNotFoundException!",Toast.LENGTH_SHORT).show();
                e.printStackTrace();
            }
            catch (IOException e)
            {
                Toast.makeText(MainActivity.this,"Io Exception!",Toast.LENGTH_SHORT).show();
                e.printStackTrace();
            }

        }

                String line_1 = null;
                String line_2=null;
        try
        {
            BufferedReader br = new BufferedReader(new FileReader(file));
            line_1 = br.readLine();
            line_2 = br.readLine();
        }
        catch (FileNotFoundException e)
        {
            e.printStackTrace();
        }
        catch (IOException e)
        {
            e.printStackTrace();
        }

       if(editText1.getText().toString().trim().equals(line_1) &&  editText2.getText().toString().trim().equals(line_2))
       {
           startActivity(intent);
       }
       else
       {
           Toast.makeText(getApplicationContext(), "Invalid login...", Toast.LENGTH_LONG).show();
      }
    }
}

