package com.example.teacher_management_system;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.os.Environment;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;

public class AddRecord extends AppCompatActivity
{

    @Override
       protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_record);
    }


    public void add(View view)
    {
        Intent intent = new Intent(this,add.class);
        startActivity(intent);
    }


    public void check_attendance(View view)
    {
        Intent intent = new Intent(this,check_attendance.class);
        startActivity(intent);
    }


    public void search(View view)
    {
        Intent intent= new Intent(this,search_1.class);
        startActivity(intent);
    }

    public void grade(View view)
    {
        Intent intent = new Intent(this,grade_1.class);
        startActivity(intent);
    }

}