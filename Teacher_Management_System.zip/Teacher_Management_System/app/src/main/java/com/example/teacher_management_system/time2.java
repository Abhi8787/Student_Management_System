package com.example.teacher_management_system;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.os.Environment;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;


public class time2 extends AppCompatActivity
{

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_time2);
    }


    public void edit(View view)
    {

        File currentDir = getFilesDir();

        EditText editText1  = findViewById(R.id.editTextTextPersonName45);
        EditText editText2  = findViewById(R.id.editTextTextPersonName46);
        EditText editText3  = findViewById(R.id.editTextTextPersonName47);
        EditText editText4  = findViewById(R.id.editTextTextPersonName49);
        EditText editText5  = findViewById(R.id.editTextTextPersonName50);
        EditText editText6  = findViewById(R.id.editTextTextPersonName48);
        EditText editText7  = findViewById(R.id.editTextTextPersonName51);
        EditText editText8  = findViewById(R.id.editTextTextPersonName52);
        EditText editText9  = findViewById(R.id.editTextTextPersonName53);
        EditText editText10 = findViewById(R.id.editTextTextPersonName54);
        EditText editText11 = findViewById(R.id.editTextTextPersonName55);
        EditText editText12 = findViewById(R.id.editTextTextPersonName56);
        EditText editText13 = findViewById(R.id.editTextTextPersonName57);
        EditText editText14 = findViewById(R.id.editTextTextPersonName58);
        EditText editText15 = findViewById(R.id.editTextTextPersonName59);
        EditText editText16 = findViewById(R.id.editTextTextPersonName60);
        EditText editText17 = findViewById(R.id.editTextTextPersonName61);
        EditText editText18 = findViewById(R.id.editTextTextPersonName30);
        EditText editText19 = findViewById(R.id.editTextTextPersonName73);
        EditText editText20 = findViewById(R.id.editTextTextPersonName62);
        EditText editText21 = findViewById(R.id.editTextTextPersonName63);
        EditText editText22 = findViewById(R.id.editTextTextPersonName64);
        EditText editText23 = findViewById(R.id.editTextTextPersonName66);
        EditText editText24 = findViewById(R.id.editTextTextPersonName65);
        EditText editText25 = findViewById(R.id.editTextTextPersonName67);
        EditText editText26 = findViewById(R.id.editTextTextPersonName68);
        EditText editText27 = findViewById(R.id.editTextTextPersonName69);
        EditText editText28 = findViewById(R.id.editTextTextPersonName70);
        EditText editText29 = findViewById(R.id.editTextTextPersonName71);
        EditText editText30 = findViewById(R.id.editTextTextPersonName72);




        File file1  = new File(currentDir,"1.txt");
        File file2  = new File(currentDir,"2.txt");
        File file3  = new File(currentDir,"3.txt");
        File file4  = new File(currentDir,"4.txt");
        File file5  = new File(currentDir,"5.txt");
        File file6  = new File(currentDir,"6.txt");
        File file7  = new File(currentDir,"7.txt");
        File file8  = new File(currentDir,"8.txt");
        File file9  = new File(currentDir,"9.txt");
        File file10 = new File(currentDir,"10.txt");
        File file11 = new File(currentDir,"11.txt");
        File file12 = new File(currentDir,"12.txt");
        File file13 = new File(currentDir,"13.txt");
        File file14 = new File(currentDir,"14.txt");
        File file15 = new File(currentDir,"15.txt");
        File file16 = new File(currentDir,"16.txt");
        File file17 = new File(currentDir,"17.txt");
        File file18 = new File(currentDir,"18.txt");
        File file19 = new File(currentDir,"19.txt");
        File file20 = new File(currentDir,"20.txt");
        File file21 = new File(currentDir,"21.txt");
        File file22 = new File(currentDir,"22.txt");
        File file23 = new File(currentDir,"23.txt");
        File file24 = new File(currentDir,"24.txt");
        File file25 = new File(currentDir,"25.txt");
        File file26 = new File(currentDir,"26.txt");
        File file27 = new File(currentDir,"27.txt");
        File file28 = new File(currentDir,"28.txt");
        File file29 = new File(currentDir,"29.txt");
        File file30 = new File(currentDir,"30.txt");



        try
        {

            FileWriter fw1  = new FileWriter(file1);
            FileWriter fw2  = new FileWriter(file2);
            FileWriter fw3  = new FileWriter(file3);
            FileWriter fw4  = new FileWriter(file4);
            FileWriter fw5  = new FileWriter(file5);
            FileWriter fw6  = new FileWriter(file6);
            FileWriter fw7  = new FileWriter(file7);
            FileWriter fw8  = new FileWriter(file8);
            FileWriter fw9  = new FileWriter(file9);
            FileWriter fw10  = new FileWriter(file10);
            FileWriter fw11  = new FileWriter(file11);
            FileWriter fw12  = new FileWriter(file12);
            FileWriter fw13  = new FileWriter(file13);
            FileWriter fw14  = new FileWriter(file14);
            FileWriter fw15  = new FileWriter(file15);
            FileWriter fw16  = new FileWriter(file16);
            FileWriter fw17  = new FileWriter(file17);
            FileWriter fw18  = new FileWriter(file18);
            FileWriter fw19  = new FileWriter(file19);
            FileWriter fw20  = new FileWriter(file20);
            FileWriter fw21  = new FileWriter(file21);
            FileWriter fw22  = new FileWriter(file22);
            FileWriter fw23  = new FileWriter(file23);
            FileWriter fw24  = new FileWriter(file24);
            FileWriter fw25  = new FileWriter(file25);
            FileWriter fw26  = new FileWriter(file26);
            FileWriter fw27  = new FileWriter(file27);
            FileWriter fw28  = new FileWriter(file28);
            FileWriter fw29  = new FileWriter(file29);
            FileWriter fw30  = new FileWriter(file30);




            PrintWriter pw1  = new PrintWriter(fw1);
            PrintWriter pw2  = new PrintWriter(fw2);
            PrintWriter pw3  = new PrintWriter(fw3);
            PrintWriter pw4  = new PrintWriter(fw4);
            PrintWriter pw5  = new PrintWriter(fw5);
            PrintWriter pw6  = new PrintWriter(fw6);
            PrintWriter pw7  = new PrintWriter(fw7);
            PrintWriter pw8  = new PrintWriter(fw8);
            PrintWriter pw9  = new PrintWriter(fw9);
            PrintWriter pw10 = new PrintWriter(fw10);
            PrintWriter pw11 = new PrintWriter(fw11);
            PrintWriter pw12 = new PrintWriter(fw12);
            PrintWriter pw13 = new PrintWriter(fw13);
            PrintWriter pw14 = new PrintWriter(fw14);
            PrintWriter pw15 = new PrintWriter(fw15);
            PrintWriter pw16 = new PrintWriter(fw16);
            PrintWriter pw17 = new PrintWriter(fw17);
            PrintWriter pw18 = new PrintWriter(fw18);
            PrintWriter pw19 = new PrintWriter(fw19);
            PrintWriter pw20 = new PrintWriter(fw20);
            PrintWriter pw21 = new PrintWriter(fw21);
            PrintWriter pw22 = new PrintWriter(fw22);
            PrintWriter pw23 = new PrintWriter(fw23);
            PrintWriter pw24 = new PrintWriter(fw24);
            PrintWriter pw25 = new PrintWriter(fw25);
            PrintWriter pw26 = new PrintWriter(fw26);
            PrintWriter pw27 = new PrintWriter(fw27);
            PrintWriter pw28 = new PrintWriter(fw28);
            PrintWriter pw29 = new PrintWriter(fw29);
            PrintWriter pw30 = new PrintWriter(fw30);


            pw1.println(editText1.getText().toString());
            pw2.println(editText2.getText().toString());
            pw3.println(editText3.getText().toString());
            pw4.println(editText4.getText().toString());
            pw5.println(editText5.getText().toString());
            pw6.println(editText6.getText().toString());
            pw7.println(editText7.getText().toString());
            pw8.println(editText8.getText().toString());
            pw9.println(editText9.getText().toString());
            pw10.println(editText10.getText().toString());
            pw11.println(editText11.getText().toString());
            pw12.println(editText12.getText().toString());
            pw13.println(editText13.getText().toString());
            pw14.println(editText14.getText().toString());
            pw15.println(editText15.getText().toString());
            pw16.println(editText16.getText().toString());
            pw17.println(editText17.getText().toString());
            pw18.println(editText18.getText().toString());
            pw19.println(editText19.getText().toString());
            pw20.println(editText20.getText().toString());
            pw21.println(editText21.getText().toString());
            pw22.println(editText22.getText().toString());
            pw23.println(editText23.getText().toString());
            pw24.println(editText24.getText().toString());
            pw25.println(editText25.getText().toString());
            pw26.println(editText26.getText().toString());
            pw27.println(editText27.getText().toString());
            pw28.println(editText28.getText().toString());
            pw29.println(editText29.getText().toString());
            pw30.println(editText30.getText().toString());



            pw1.flush();
            pw2.flush();
            pw3.flush();
            pw4.flush();
            pw5.flush();
            pw6.flush();
            pw7.flush();
            pw8.flush();
            pw9.flush();
            pw10.flush();
            pw11.flush();
            pw12.flush();
            pw13.flush();
            pw14.flush();
            pw15.flush();
            pw16.flush();
            pw17.flush();
            pw18.flush();
            pw19.flush();
            pw20.flush();
            pw21.flush();
            pw22.flush();
            pw23.flush();
            pw24.flush();
            pw25.flush();
            pw26.flush();
            pw27.flush();
            pw28.flush();
            pw29.flush();
            pw30.flush();




            pw1.close();
            pw2.close();
            pw3.close();
            pw4.close();
            pw5.close();
            pw6.close();
            pw7.close();
            pw8.close();
            pw9.close();
            pw10.close();
            pw11.close();
            pw12.close();
            pw13.close();
            pw14.close();
            pw15.close();
            pw16.close();
            pw17.close();
            pw18.close();
            pw19.close();
            pw20.close();
            pw21.close();
            pw22.close();
            pw23.close();
            pw24.close();
            pw25.close();
            pw26.close();
            pw27.close();
            pw28.close();
            pw29.close();
            pw30.close();
        }
        catch (FileNotFoundException e)
        {
            e.printStackTrace();
        }
        catch (IOException e)
        {
            e.printStackTrace();
        }

    }








    public void refresh(View view)
    {
        File currentDir = getFilesDir();



        TextView editText1  = findViewById(R.id.editTextTextPersonName45);
        TextView editText2  = findViewById(R.id.editTextTextPersonName46);
        TextView editText3  = findViewById(R.id.editTextTextPersonName47);
        TextView editText4  = findViewById(R.id.editTextTextPersonName49);
        TextView editText5  = findViewById(R.id.editTextTextPersonName50);
        TextView editText6  = findViewById(R.id.editTextTextPersonName48);
        TextView editText7  = findViewById(R.id.editTextTextPersonName51);
         TextView editText8  = findViewById(R.id.editTextTextPersonName52);
        TextView editText9  = findViewById(R.id.editTextTextPersonName53);
        TextView editText10 = findViewById(R.id.editTextTextPersonName54);
        TextView editText11 = findViewById(R.id.editTextTextPersonName55);
        TextView editText12 = findViewById(R.id.editTextTextPersonName56);
        TextView editText13 = findViewById(R.id.editTextTextPersonName57);
        TextView editText14 = findViewById(R.id.editTextTextPersonName58);
        TextView editText15 = findViewById(R.id.editTextTextPersonName59);
        TextView editText16 = findViewById(R.id.editTextTextPersonName60);
        TextView editText17 = findViewById(R.id.editTextTextPersonName61);
        TextView editText18 = findViewById(R.id.editTextTextPersonName30);
        TextView editText19 = findViewById(R.id.editTextTextPersonName73);
        TextView editText20 = findViewById(R.id.editTextTextPersonName62);
        TextView editText21 = findViewById(R.id.editTextTextPersonName63);
        TextView editText22 = findViewById(R.id.editTextTextPersonName64);
        TextView editText23 = findViewById(R.id.editTextTextPersonName66);
        TextView editText24 = findViewById(R.id.editTextTextPersonName65);
        TextView editText25 = findViewById(R.id.editTextTextPersonName67);
        TextView editText26 = findViewById(R.id.editTextTextPersonName68);
        TextView editText27 = findViewById(R.id.editTextTextPersonName69);
        TextView editText28 = findViewById(R.id.editTextTextPersonName70);
        TextView editText29 = findViewById(R.id.editTextTextPersonName71);
        TextView editText30 = findViewById(R.id.editTextTextPersonName72);



        File file1  = new File(currentDir,"1.txt");
        File file2  = new File(currentDir,"2.txt");
        File file3  = new File(currentDir,"3.txt");
        File file4  = new File(currentDir,"4.txt");
        File file5  = new File(currentDir,"5.txt");
        File file6  = new File(currentDir,"6.txt");
        File file7  = new File(currentDir,"7.txt");
        File file8  = new File(currentDir,"8.txt");
        File file9  = new File(currentDir,"9.txt");
        File file10 = new File(currentDir,"10.txt");
        File file11 = new File(currentDir,"11.txt");
        File file12 = new File(currentDir,"12.txt");
        File file13 = new File(currentDir,"13.txt");
        File file14 = new File(currentDir,"14.txt");
        File file15 = new File(currentDir,"15.txt");
        File file16 = new File(currentDir,"16.txt");
        File file17 = new File(currentDir,"17.txt");
        File file18 = new File(currentDir,"18.txt");
        File file19 = new File(currentDir,"19.txt");
        File file20 = new File(currentDir,"20.txt");
        File file21 = new File(currentDir,"21.txt");
        File file22 = new File(currentDir,"22.txt");
        File file23 = new File(currentDir,"23.txt");
        File file24 = new File(currentDir,"24.txt");
        File file25 = new File(currentDir,"25.txt");
        File file26 = new File(currentDir,"26.txt");
        File file27 = new File(currentDir,"27.txt");
        File file28 = new File(currentDir,"28.txt");
        File file29 = new File(currentDir,"29.txt");
        File file30 = new File(currentDir,"30.txt");



        try
        {
            BufferedReader br1 = new BufferedReader(new FileReader(file1));
            BufferedReader br2 = new BufferedReader(new FileReader(file2));
            BufferedReader br3  = new BufferedReader(new FileReader(file3));
            BufferedReader br4  = new BufferedReader(new FileReader(file4));
            BufferedReader br5  = new BufferedReader(new FileReader(file5));
            BufferedReader br6  = new BufferedReader(new FileReader(file6));
            BufferedReader br7  = new BufferedReader(new FileReader(file7));
            BufferedReader br8  = new BufferedReader(new FileReader(file8));
            BufferedReader br9  = new BufferedReader(new FileReader(file9));
            BufferedReader br10 = new BufferedReader(new FileReader(file10));
            BufferedReader br11 = new BufferedReader(new FileReader(file11));
            BufferedReader br12 = new BufferedReader(new FileReader(file12));
            BufferedReader br13 = new BufferedReader(new FileReader(file13));
            BufferedReader br14 = new BufferedReader(new FileReader(file14));
            BufferedReader br15 = new BufferedReader(new FileReader(file15));
            BufferedReader br16 = new BufferedReader(new FileReader(file16));
            BufferedReader br17 = new BufferedReader(new FileReader(file17));
            BufferedReader br18 = new BufferedReader(new FileReader(file18));
            BufferedReader br19 = new BufferedReader(new FileReader(file19));
            BufferedReader br20 = new BufferedReader(new FileReader(file20));
            BufferedReader br21 = new BufferedReader(new FileReader(file21));
            BufferedReader br22 = new BufferedReader(new FileReader(file22));
            BufferedReader br23 = new BufferedReader(new FileReader(file23));
            BufferedReader br24 = new BufferedReader(new FileReader(file24));
            BufferedReader br25 = new BufferedReader(new FileReader(file25));
            BufferedReader br26 = new BufferedReader(new FileReader(file26));
            BufferedReader br27 = new BufferedReader(new FileReader(file27));
            BufferedReader br28 = new BufferedReader(new FileReader(file28));
            BufferedReader br29 = new BufferedReader(new FileReader(file29));
            BufferedReader br30 = new BufferedReader(new FileReader(file30));




            String line1  = br1.readLine();
            String line2  = br2.readLine();
            String line3  = br3.readLine();
            String line4  = br4.readLine();
            String line5  = br5.readLine();
            String line6  = br6.readLine();
            String line7  = br7.readLine();
            String line8  = br8.readLine();
            String line9  = br9.readLine();
            String line10 = br10.readLine();
            String line11 = br11.readLine();
            String line12 = br12.readLine();
            String line13 = br13.readLine();
            String line14 = br14.readLine();
            String line15 = br15.readLine();
            String line16 = br16.readLine();
            String line17 = br17.readLine();
            String line18 = br18.readLine();
            String line19 = br19.readLine();
            String line20 = br20.readLine();
            String line21 = br21.readLine();
            String line22 = br22.readLine();
            String line23 = br23.readLine();
            String line24 = br24.readLine();
            String line25 = br25.readLine();
            String line26 = br26.readLine();
            String line27 = br27.readLine();
            String line28 = br28.readLine();
            String line29 = br29.readLine();
            String line30 = br30.readLine();




            editText1.setText(line1);
            editText2.setText(line2);
            editText3.setText(line3);
            editText4.setText(line4);
            editText5.setText(line5);
            editText6.setText(line6);
            editText7.setText(line7);
            editText8.setText(line8);
            editText9.setText(line9);
            editText10.setText(line10);
            editText11.setText(line11);
            editText12.setText(line12);
            editText13.setText(line13);
            editText14.setText(line14);
            editText15.setText(line15);
            editText16.setText(line16);
            editText17.setText(line17);
            editText18.setText(line18);
            editText19.setText(line19);
            editText20.setText(line20);
            editText21.setText(line21);
            editText22.setText(line22);
            editText23.setText(line23);
            editText24.setText(line24);
            editText25.setText(line25);
            editText26.setText(line26);
            editText27.setText(line27);
            editText28.setText(line28);
            editText29.setText(line29);
            editText30.setText(line30);




            br1.close();
            br2.close();
            br3.close();
            br4.close();
            br5.close();
            br6.close();
            br7.close();
            br8.close();
            br9.close();
            br10.close();
            br11.close();
            br12.close();
            br13.close();
            br14.close();
            br15.close();
            br16.close();
            br17.close();
            br18.close();
            br19.close();
            br20.close();
            br21.close();
            br22.close();
            br23.close();
            br24.close();
            br25.close();
            br26.close();
            br27.close();
            br28.close();
            br29.close();
            br30.close();

        }



        catch (FileNotFoundException e)
        {
            e.printStackTrace();
        }
        catch (IOException e)
        {
            e.printStackTrace();
        }

    }

}