package com.example.teacher_management_system;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.io.File;

public class mainmenu extends AppCompatActivity
{

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_mainmenu);
    }

   public void addRecord(View view)
   {
     Intent intent = new Intent(this,AddRecord.class);
     startActivity(intent);
   }

    public void attendance(View view)
   {
      Intent intent = new Intent(this,Attendence.class);
      startActivity(intent);
   }

   public void timetable(View view)
    {

                Intent intent = new Intent(this,time2.class);
                startActivity(intent);
    }


    public void grading(View view)
    {
        Intent intent = new Intent(this,grading_1.class);
        startActivity(intent);
    }

    public void about(View view)
    {
        Intent intent = new Intent(this,about.class);
        startActivity(intent);
    }

}


