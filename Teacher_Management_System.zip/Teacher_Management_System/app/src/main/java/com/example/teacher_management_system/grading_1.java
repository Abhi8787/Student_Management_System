package com.example.teacher_management_system;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.os.Environment;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

public class grading_1 extends AppCompatActivity
{

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_grading1);
    }

    public void grading_2(View view)
    {
        File currentDir = getFilesDir();

        EditText editText = findViewById(R.id.editTextTextPersonName7);
        TextView textview = findViewById(R.id.textView16);
        TextView textview1 = findViewById(R.id.textView25);
        TextView textview2 = findViewById(R.id.textView24);
        TextView textview3 = findViewById(R.id.textView43);
        TextView textview4 = findViewById(R.id.textView23);



        try
        {
            File file_1 = new File(currentDir, "grade.txt");
            BufferedReader br = new BufferedReader(new FileReader(file_1));
            String line = br.readLine();
            int i = 0;
            while (line != null)
            {
                if (editText.getText().toString().equals(line))
                {
                    line = br.readLine();
                    i=1;
                    textview.setText(line);
                    line = br.readLine();
                    textview1.setText(line);
                    line = br.readLine();
                    textview2.setText(line);
                    line = br.readLine();
                    textview3.setText(line);
                    line = br.readLine();
                    textview4.setText(line);
                    break;
                }

                line = br.readLine();
                line = br.readLine();
                line = br.readLine();
                line = br.readLine();
                line = br.readLine();
                line = br.readLine();

            }
            if(i==0)
            {
                textview.setText("Invalid");
                textview1.setText("Invalid");
                textview2.setText("Invalid");
                textview3.setText("Invalid");
                textview4.setText("Invalid");
            }

            br.close();

        }

        catch (FileNotFoundException e)
        {
            e.printStackTrace();
        }

        catch (IOException e)
        {
            e.printStackTrace();
        }

    }


}
