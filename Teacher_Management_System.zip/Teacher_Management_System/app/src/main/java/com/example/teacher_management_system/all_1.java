package com.example.teacher_management_system;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.os.Environment;
import android.view.View;
import android.widget.TextView;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

public class all_1 extends AppCompatActivity {



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_all1);
    }






    public void next (View view)
    {
        Intent intent = new Intent(this,all_2.class);
        startActivity(intent);
    }




    public void refresh(View view) {

        File currentDir = getFilesDir();

        TextView textview = findViewById(R.id.textView19);
        TextView textview1 = findViewById(R.id.textView60);
        TextView textview2 = findViewById(R.id.textView59);
        TextView textview3 = findViewById(R.id.textView58);
        TextView textview4 = findViewById(R.id.textView57);
        TextView textview5 = findViewById(R.id.textView56);
        TextView textview6 = findViewById(R.id.textView55);
        TextView textview7 = findViewById(R.id.textView54);
        TextView textview8 = findViewById(R.id.textView52);
        TextView textview9 = findViewById(R.id.textView3);
        TextView textview10 = findViewById(R.id.textView50);
        TextView textview11 = findViewById(R.id.textView65);
        TextView textview12 = findViewById(R.id.textView64);
        TextView textview13 = findViewById(R.id.textView63);
        TextView textview14 = findViewById(R.id.textView62);
        TextView textview15 = findViewById(R.id.textView61);
        TextView textview16 = findViewById(R.id.textView53);
        TextView textview17 = findViewById(R.id.textView51);

        try
        {
            File file = new File(currentDir, "data.txt");
            BufferedReader br = new BufferedReader(new FileReader(file));
            String line = br.readLine();
            for(int k=1;k<=45;k++)
                line = br.readLine();
            int i = 1;
            while (line != null)
            {

                line = br.readLine();
                switch (i)
                {
                    case 1:
                        textview.setText(line);
                        line = br.readLine();
                        break;

                    case 2:
                        textview1.setText(line);
                        line = br.readLine();
                        break;


                    case 3:
                        textview2.setText(line);
                        line = br.readLine();
                        break;


                    case 4:
                        textview3.setText(line);
                        line = br.readLine();
                        break;


                    case 5:
                        textview4.setText(line);
                        line = br.readLine();
                        break;


                    case 6:
                        textview5.setText(line);
                        line = br.readLine();
                        break;


                    case 7:
                        textview6.setText(line);
                        line = br.readLine();
                        break;


                    case 8:
                        textview7.setText(line);
                        line = br.readLine();
                        break;


                    case 9:
                        textview8.setText(line);
                        line = br.readLine();
                        break;

                }
                line = br.readLine();
                line = br.readLine();
                line = br.readLine();
                i++;

            }


                File f10 = new File(currentDir, "19CSE1010.txt");
                long j10 = f10.length();
                textview9.setText(String.valueOf(j10));

                File f11 = new File(currentDir, "19CSE1011.txt");
                long j11 = f11.length();
                textview10.setText(String.valueOf(j11));


                File f12 = new File(currentDir, "19CSE1012.txt");
                long j12 = f12.length();
                textview11.setText(String.valueOf(j12));


                File f13 = new File(currentDir, "19CSE1013.txt");
                long j13 = f13.length();
                textview12.setText(String.valueOf(j13));

                File f14 = new File(currentDir, "19CSE1014.txt");
                long j14 = f14.length();
                textview13.setText(String.valueOf(j14));

                File f15 = new File(currentDir, "19CSE1015.txt");
                long j15 = f15.length();
                textview14.setText(String.valueOf(j15));


                File f16 = new File(currentDir, "19CSE1016.txt");
                long j16 = f16.length();
                textview15.setText(String.valueOf(j16));

                File f17 = new File(currentDir, "19CSE1017.txt");
                long j17 = f17.length();
                textview16.setText(String.valueOf(j17));

                File f18 = new File(currentDir, "19CSE1018.txt");
                long j18 = f18.length();
                textview17.setText(String.valueOf(j18));

                br.close();
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }


    }
}