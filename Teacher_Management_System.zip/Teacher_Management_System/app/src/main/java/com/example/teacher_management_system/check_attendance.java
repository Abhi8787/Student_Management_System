package com.example.teacher_management_system;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.os.Environment;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

public class check_attendance extends AppCompatActivity
{
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_check_attendance);
    }

    public void dowork(View view)
    {

        File currentDir = getFilesDir();

        EditText editText = findViewById(R.id.editTextTextPersonName7);
        TextView textview = findViewById(R.id.textView20);
        TextView textview1 = findViewById(R.id.textView17);
        TextView textview2 = findViewById(R.id.textView13);

        try
        {
        File file = new File(currentDir,"set.txt");
        File filee = new File(currentDir, "data.txt");
        BufferedReader br = new BufferedReader(new FileReader(filee));
        String line = br.readLine();
        long j = file.length();
            int flag=0;
            int i = 1;
            String temp = null;
            while(line!=null)
            {
                temp = line;
                line=br.readLine();
                if(editText.getText().toString().equals(line))
                {
                    flag=1;
                    break;
                }

                line = br.readLine();
                line = br.readLine();
                line = br.readLine();
                line = br.readLine();
                i++;

            }
            br.close();

            if(flag==1) {
                switch (i) {
                    case 1:

                        File f1 = new File(currentDir, "19CSE1001.txt");
                        long j1 = f1.length();
                        textview1.setText(String.valueOf(j1));
                        textview.setText(String.valueOf(j));
                        textview2.setText(temp);
                        break;


                    case 2:

                        File f2 = new File(currentDir, "19CSE1002.txt");
                        long j2 = f2.length();
                        textview1.setText(String.valueOf(j2));
                        textview.setText(String.valueOf(j));
                        textview2.setText(temp);
                        break;


                    case 3:

                        File f3 = new File(currentDir, "19CSE1003.txt");
                        long j3 = f3.length();
                        textview1.setText(String.valueOf(j3));
                        textview.setText(String.valueOf(j));
                        textview2.setText(temp);
                        break;


                    case 4:

                        File f4 = new File(currentDir, "19CSE1004.txt");
                        long j4 = f4.length();
                        textview1.setText(String.valueOf(j4));
                        textview.setText(String.valueOf(j));
                        textview2.setText(temp);
                        break;


                    case 5:

                        File f5 = new File(currentDir, "19CSE1005.txt");
                        long j5 = f5.length();
                        textview1.setText(String.valueOf(j5));
                        textview.setText(String.valueOf(j));
                        textview2.setText(temp);
                        break;


                    case 6:

                        File f6 = new File(currentDir, "19CSE1006.txt");
                        long j6 = f6.length();
                        textview1.setText(String.valueOf(j6));
                        textview.setText(String.valueOf(j));
                        textview2.setText(temp);
                        break;


                    case 7:

                        File f7 = new File(currentDir, "19CSE1007.txt");
                        long j7 = f7.length();
                        textview1.setText(String.valueOf(j7));
                        textview.setText(String.valueOf(j));
                        textview2.setText(temp);
                        break;


                    case 8:

                        File f8 = new File(currentDir, "19CSE1008.txt");
                        long j8 = f8.length();
                        textview1.setText(String.valueOf(j8));
                        textview.setText(String.valueOf(j));
                        textview2.setText(temp);
                        break;


                    case 9:

                        File f9 = new File(currentDir, "19CSE1009.txt");
                        long j9 = f9.length();
                        textview1.setText(String.valueOf(j9));
                        textview.setText(String.valueOf(j));
                        textview2.setText(temp);
                        break;


                    case 10:

                        File f10 = new File(currentDir, "19CSE1010.txt");
                        long j10 = f10.length();
                        textview1.setText(String.valueOf(j10));
                        textview.setText(String.valueOf(j));
                        textview2.setText(temp);
                        break;


                    case 11:

                        File f11 = new File(currentDir, "19CSE1011.txt");
                        long j11 = f11.length();
                        textview1.setText(String.valueOf(j11));
                        textview.setText(String.valueOf(j));
                        textview2.setText(temp);
                        break;


                    case 12:

                        File f12 = new File(currentDir, "19CSE1012.txt");
                        long j12 = f12.length();
                        textview1.setText(String.valueOf(j12));
                        textview.setText(String.valueOf(j));
                        textview2.setText(temp);
                        break;


                    case 13:

                        File f13 = new File(currentDir, "19CSE1013.txt");
                        long j13 = f13.length();
                        textview1.setText(String.valueOf(j13));
                        textview.setText(String.valueOf(j));
                        textview2.setText(temp);
                        break;


                    case 14:

                        File f14 = new File(currentDir, "19CSE1014.txt");
                        long j14 = f14.length();
                        textview1.setText(String.valueOf(j14));
                        textview.setText(String.valueOf(j));
                        textview2.setText(temp);
                        break;


                    case 15:

                        File f15 = new File(currentDir, "19CSE1015.txt");
                        long j15 = f15.length();
                        textview1.setText(String.valueOf(j15));
                        textview.setText(String.valueOf(j));
                        textview2.setText(temp);
                        break;


                    case 16:

                        File f16 = new File(currentDir, "19CSE1016.txt");
                        long j16 = f16.length();
                        textview1.setText(String.valueOf(j16));
                        textview.setText(String.valueOf(j));
                        textview2.setText(temp);
                        break;


                    case 17:

                        File f17 = new File(currentDir, "19CSE1017.txt");
                        long j17 = f17.length();
                        textview1.setText(String.valueOf(j17));
                        textview.setText(String.valueOf(j));
                        textview2.setText(temp);
                        break;


                    case 18:

                        File f18 = new File(currentDir, "19CSE1018.txt");
                        long j18 = f18.length();
                        textview1.setText(String.valueOf(j18));
                        textview.setText(String.valueOf(j));
                        textview2.setText(temp);
                        break;


                    case 19:

                        File f19 = new File(currentDir, "19CSE1019.txt");
                        long j19 = f19.length();
                        textview1.setText(String.valueOf(j19));
                        textview.setText(String.valueOf(j));
                        textview2.setText(temp);
                        break;


                    case 20:

                        File f20 = new File(currentDir, "19CSE1020.txt");
                        long j20 = f20.length();
                        textview1.setText(String.valueOf(j20));
                        textview.setText(String.valueOf(j));
                        textview2.setText(temp);
                        break;


                    case 21:

                        File f21 = new File(currentDir, "19CSE1021.txt");
                        long j21 = f21.length();
                        textview1.setText(String.valueOf(j21));
                        textview.setText(String.valueOf(j));
                        textview2.setText(temp);
                        break;


                    case 22:

                        File f22 = new File(currentDir, "19CSE1022.txt");
                        long j22 = f22.length();
                        textview1.setText(String.valueOf(j22));
                        textview.setText(String.valueOf(j));
                        textview2.setText(temp);
                        break;


                    case 23:

                        File f23 = new File(currentDir, "19CSE1023.txt");
                        long j23 = f23.length();
                        textview1.setText(String.valueOf(j23));
                        textview.setText(String.valueOf(j));
                        textview2.setText(temp);
                        break;


                    case 24:

                        File f24 = new File(currentDir, "19CSE1024.txt");
                        long j24 = f24.length();
                        textview1.setText(String.valueOf(j24));
                        textview.setText(String.valueOf(j));
                        textview2.setText(temp);
                        break;


                    case 25:

                        File f25 = new File(currentDir, "19CSE1025.txt");
                        long j25 = f25.length();
                        textview1.setText(String.valueOf(j25));
                        textview.setText(String.valueOf(j));
                        textview2.setText(temp);
                        break;


                    case 26:

                        File f26 = new File(currentDir, "19CSE1026.txt");
                        long j26 = f26.length();
                        textview1.setText(String.valueOf(j26));
                        textview.setText(String.valueOf(j));
                        textview2.setText(temp);
                        break;


                    case 27:

                        File f27 = new File(currentDir, "19CSE1027.txt");
                        long j27 = f27.length();
                        textview1.setText(String.valueOf(j27));
                        textview.setText(String.valueOf(j));
                        textview2.setText(temp);
                        break;


                    default:
                        textview2.setText("Invalid");
                        textview1.setText("Invalid");
                        textview.setText("Invalid");


                }
            }
            else
            {
                textview1.setText("Invalid");
                textview.setText("Invalid");
                textview2.setText("Invalid");
            }
        }

        catch (FileNotFoundException e)
        {
            e.printStackTrace();
        }

        catch (IOException e)
        {
            e.printStackTrace();
        }

    }


    public void all(View view)
    {
        Intent intent = new Intent(this,all.class);
        startActivity(intent);
    }

}