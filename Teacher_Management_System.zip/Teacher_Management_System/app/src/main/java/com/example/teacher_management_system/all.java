package com.example.teacher_management_system;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.os.Environment;
import android.view.View;
import android.widget.TextView;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

public class all extends AppCompatActivity
{

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_all);
    }


    public void refresh(View view) {

        File currentDir = getFilesDir();

        TextView textview = findViewById(R.id.textView52);
        TextView textview1 = findViewById(R.id.textView19);
        TextView textview2 = findViewById(R.id.textView60);
        TextView textview3 = findViewById(R.id.textView59);
        TextView textview4 = findViewById(R.id.textView58);
        TextView textview5 = findViewById(R.id.textView57);
        TextView textview6 = findViewById(R.id.textView56);
        TextView textview7 = findViewById(R.id.textView55);
        TextView textview8 = findViewById(R.id.textView54);
        TextView textview9 = findViewById(R.id.textView3);
        TextView textview10 = findViewById(R.id.textView50);
        TextView textview11 = findViewById(R.id.textView65);
        TextView textview12 = findViewById(R.id.textView64);
        TextView textview13 = findViewById(R.id.textView63);
        TextView textview14 = findViewById(R.id.textView62);
        TextView textview15 = findViewById(R.id.textView61);
        TextView textview16 = findViewById(R.id.textView53);
        TextView textview17 = findViewById(R.id.textView51);

        try
        {
            File file = new File(currentDir, "data.txt");
            BufferedReader br = new BufferedReader(new FileReader(file));
            String line = br.readLine();
            int i = 1;
            while (line != null)
            {

                line = br.readLine();
                switch (i)
                {
                    case 1:
                        textview.setText(line);
                        line = br.readLine();
                        break;

                    case 2:
                        textview1.setText(line);
                        line = br.readLine();
                        break;


                    case 3:
                        textview2.setText(line);
                        line = br.readLine();
                        break;


                    case 4:
                        textview3.setText(line);
                        line = br.readLine();
                        break;


                    case 5:
                        textview4.setText(line);
                        line = br.readLine();
                        break;


                    case 6:
                        textview5.setText(line);
                        line = br.readLine();
                        break;


                    case 7:
                        textview6.setText(line);
                        line = br.readLine();
                        break;


                    case 8:
                        textview7.setText(line);
                        line = br.readLine();
                        break;


                    case 9:
                        textview8.setText(line);
                        line = br.readLine();
                        break;

                }
                line = br.readLine();
                line = br.readLine();
                line = br.readLine();
                i++;

            }

                File f1 = new File(currentDir, "19CSE1001.txt");
                long j1 = f1.length();
                textview9.setText(String.valueOf(j1));

                File f2 = new File(currentDir, "19CSE1002.txt");
                long j2 = f2.length();
                textview10.setText(String.valueOf(j2));

                File f3 = new File(currentDir, "19CSE1003.txt");
                long j3 = f3.length();
                textview11.setText(String.valueOf(j3));

                File f4 = new File(currentDir, "19CSE1004.txt");
                long j4 = f4.length();
                textview12.setText(String.valueOf(j4));

                File f5 = new File(currentDir, "19CSE1005.txt");
                long j5 = f5.length();
                textview13.setText(String.valueOf(j5));

                File f6 = new File(currentDir, "19CSE1006.txt");
                long j6 = f6.length();
                textview14.setText(String.valueOf(j6));

                File f7 = new File(currentDir, "19CSE1007.txt");
                long j7 = f7.length();
                textview15.setText(String.valueOf(j7));

                File f8 = new File(currentDir, "19CSE1008.txt");
                long j8 = f8.length();
                textview16.setText(String.valueOf(j8));

                File f9 = new File(currentDir, "19CSE1009.txt");
                long j9 = f9.length();
                textview17.setText(String.valueOf(j9));

                br.close();
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }



    }




    public void next(View view) {
        Intent intent = new Intent(this, all_1.class);
        startActivity(intent);
    }
}