
package com.example.teacher_management_system;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.os.Environment;
import android.view.View;
import android.widget.TextView;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;

public class attendance1 extends AppCompatActivity
{
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_attendance1);
    }

    public void next (View view)
    {
        Intent intent = new Intent(this,attend2.class);
        startActivity(intent);
    }




    public void refresh(View view) {

        File currentDir = getFilesDir();

        TextView textview = findViewById(R.id.textView19);
        TextView textview1 = findViewById(R.id.textView60);
        TextView textview2 = findViewById(R.id.textView59);
        TextView textview3 = findViewById(R.id.textView58);
        TextView textview4 = findViewById(R.id.textView57);
        TextView textview5 = findViewById(R.id.textView56);
        TextView textview6 = findViewById(R.id.textView55);
        TextView textview7 = findViewById(R.id.textView54);
        TextView textview8 = findViewById(R.id.textView52);

        try
        {
            File file = new File(currentDir, "data.txt");
            BufferedReader br = new BufferedReader(new FileReader(file));
            String line = br.readLine();
            for(int k=1;k<=45;k++)
            line = br.readLine();
            int i = 1;
            while (line != null)
            {

                line = br.readLine();
                switch (i)
                {
                    case 1:
                        textview.setText(line);
                        line = br.readLine();
                        break;

                    case 2:
                        textview1.setText(line);
                        line = br.readLine();
                        break;


                    case 3:
                        textview2.setText(line);
                        line = br.readLine();
                        break;


                    case 4:
                        textview3.setText(line);
                        line = br.readLine();
                        break;


                    case 5:
                        textview4.setText(line);
                        line = br.readLine();
                        break;


                    case 6:
                        textview5.setText(line);
                        line = br.readLine();
                        break;


                    case 7:
                        textview6.setText(line);
                        line = br.readLine();
                        break;


                    case 8:
                        textview7.setText(line);
                        line = br.readLine();
                        break;


                    case 9:
                        textview8.setText(line);
                        line = br.readLine();
                        break;

                }
                line = br.readLine();
                line = br.readLine();
                line = br.readLine();
                i++;

            }

            br.close();
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }


    }


    public void CSE1001(View view) {

        File currentDir = getFilesDir();

        File file = new File(currentDir, "19CSE1010.txt");
        try {

            FileWriter fw = new FileWriter(file,true);
            PrintWriter pw = new PrintWriter(fw);
            pw.print("P");
            pw.flush();
            pw.close();

        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }


    public void CSE1002(View view) {

        File currentDir = getFilesDir();

        File file = new File(currentDir, "19CSE1011.txt");
        try {

            FileWriter fw = new FileWriter(file,true);
            PrintWriter pw = new PrintWriter(fw);
            pw.print("P");
            pw.flush();
            pw.close();

        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }


    public void CSE1003(View view) {
        File currentDir = getFilesDir();

        File file = new File(currentDir, "19CSE1012.txt");
        try {

            FileWriter fw = new FileWriter(file,true);
            PrintWriter pw = new PrintWriter(fw);
            pw.print("P");
            pw.flush();
            pw.close();

        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }


    public void CSE1004(View view) {
        File currentDir = getFilesDir();

        File file = new File(currentDir, "19CSE1013.txt");
        try {

            FileWriter fw = new FileWriter(file,true);
            PrintWriter pw = new PrintWriter(fw);
            pw.print("P");
            pw.flush();
            pw.close();

        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }


    public void CSE1005(View view) {

        File currentDir = getFilesDir();

        File file = new File(currentDir, "19CSE1014.txt");
        try {

            FileWriter fw = new FileWriter(file,true);
            PrintWriter pw = new PrintWriter(fw);
            pw.print("P");
            pw.flush();
            pw.close();

        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }


    public void CSE1006(View view) {

        File currentDir = getFilesDir();

        File file = new File(currentDir, "19CSE1015.txt");
        try {

            FileWriter fw = new FileWriter(file,true);
            PrintWriter pw = new PrintWriter(fw);
            pw.print("P");
            pw.flush();
            pw.close();

        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }


    public void CSE1007(View view) {

        File currentDir = getFilesDir();

        File file = new File(currentDir, "19CSE1016.txt");
        try {

            FileWriter fw = new FileWriter(file,true);
            PrintWriter pw = new PrintWriter(fw);
            pw.print("P");
            pw.flush();
            pw.close();

        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }


    public void CSE1008(View view) {

        File currentDir = getFilesDir();

        File file = new File(currentDir, "19CSE1017.txt");
        try {

            FileWriter fw = new FileWriter(file,true);
            PrintWriter pw = new PrintWriter(fw);
            pw.print("P");
            pw.flush();
            pw.close();

        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }


    public void CSE1009(View view) {

        File currentDir = getFilesDir();

        File file = new File(currentDir, "19CSE1018.txt");
        try {

            FileWriter fw = new FileWriter(file,true);
            PrintWriter pw = new PrintWriter(fw);
            pw.print("P");
            pw.flush();
            pw.close();

        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}