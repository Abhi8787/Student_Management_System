package com.example.teacher_management_system;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.os.Environment;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;

public class forgot extends AppCompatActivity
{
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_forgot);
    }


    public void ok(View view)
    {

        File currentDir = getFilesDir();

        EditText editText =  findViewById(R.id.editTextTextPersonName13);
        EditText editText1 = findViewById(R.id.editTextTextPersonName15);
        EditText editText2 = findViewById(R.id.editTextTextPersonName16);
        TextView textview =  findViewById(R.id.editTextTextPersonName13);
        TextView textview1 = findViewById(R.id.editTextTextPersonName15);
        TextView textview2 = findViewById(R.id.editTextTextPersonName16);

        String line=null;

        File file_1 = new File(currentDir, "security.txt");
        if (file_1.exists())
        {
            try
            {
                BufferedReader br = new BufferedReader(new FileReader(file_1));
                line = br.readLine();
                br.close();
                if (editText.getText().toString().equals(line)) {
                    File file = new File(currentDir, "login.txt");
                    PrintWriter pw = new PrintWriter(file);
                    pw.println(editText1.getText().toString());
                    pw.println(editText2.getText().toString());
                    pw.flush();
                    pw.close();
                }

                else

                {
                    textview.setText("Security code Invalid");
                    textview1.setText("Invalid");
                    textview2.setText("Invalid");
                }


            }

            catch (FileNotFoundException e)
            {
                    e.printStackTrace();
            }

            catch (IOException e)
            {
                    e.printStackTrace();
            }


        }
        else
        {
            textview.setText("First Set Security code");
            textview1.setText("Set Security code");
            textview2.setText("Set Security Code");
        }

    }


    public void set(View view)
    {

        File currentDir = getFilesDir();

        EditText editText = findViewById(R.id.editTextTextPersonName13);
        TextView textview = findViewById(R.id.editTextTextPersonName13);
        File file = new File(currentDir,"security.txt");
        if(!(file.exists()))
        {
            try
            {
                FileWriter fw = new FileWriter(file);
                PrintWriter pw = new PrintWriter(fw);
                pw.println(editText.getText().toString().trim());
                pw.close();
                fw.close();
            }
            catch (FileNotFoundException e)
            {
                e.printStackTrace();
            }
            catch (IOException e)
            {
                e.printStackTrace();
            }

        }
        else
          {
              textview.setText("You cannot Set");
          }
        }
    }



